<title>Performance Heating and Cooling</title>
<meta name="description" content="We service, repair, sell and install Residential and Commercial Heating and Cooling Systems throughout Licking, North Fairfield, and Franklin Counties of Ohio.">
<?php include('header.php'); ?>

<main>
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="7500">
  <!-- Indicators -->
<!--
 <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>

  </ol>

  Wrapper for slides

  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">      
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>  
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>  
  </ol>    -->    
  <div class="carousel-inner" role="listbox">
        
<div class="item active">
      <img src="<?php echo $base_url; ?>/img/Performance_New_Customer_Special_Banner_2022_1000x350.jpg" alt="first slide" width="100%"  >
     </div>


    <div class="item">
     <a href="request-service.php"> <img src="<?php echo $base_url; ?>/img/Fall_Furnace_TuneUp_performance.jpg" alt="second slide" width="100%">   </a>
    </div>

<div class="item" onclick="window.location = '<?php echo $base_url; ?>/request-estimate.php';">
      <img src="<?php echo $base_url; ?>/img/Performance_Blue_Banner_2022.png" alt="third slide" width="100%">   
    </div> 


    <div class="item" onclick="window.location = '<?php echo $base_url; ?>/contact-us.php';">
      <img src="<?php echo $base_url; ?>/img/financing_banner.jpg" alt="Fourth slide" width="100%">   
    </div> 

   <div class="item">
      <img src="<?php echo $base_url; ?>/img/Performance_Banner_2022.jpg" alt="fifth slide" width="100%">

    </div>

       <div class="item" onclick="window.location = '<?php echo $base_url; ?>/iwave.php';">
      <img src="<?php echo $base_url; ?>/img/iwave_banner_1.jpg" alt="sixth slide" width="100%">

    </div>

    </div>
  
     <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>

  </div>
<!-- Controls -->

</div><style>

@media screen and ( min-width: 481px ) { 

    .carousel-indicators li{
    height: 7px !important;
    width: 72px !important;
    border-radius: 0 !important;;
    background: #a00215;
    border: 0px !important;
    margin-right: 10px;
    }

        .carousel-indicators .active {
    border-radius: 0;
    background: #ffffff !important;
    margin-right: 10px;
    opacity: 1;
}

}

    .carousel-indicators .active {
    border-radius: 0;
    background: #ffffff !important;
    margin-right: 10px;
    opacity: 1;
}

</style>

<script>

$('.carousel-inner').carousel({

  interval: 16000;

})

</script>
<script>
$(document).ready(function(){
    $("#myCarousel").carousel({interval: 16000, autoPlay: 16000, hover: null, pause: null);

 

    $(".item").click(function(){
        $("#myCarousel").carousel(1);
    });
    $(".item2").click(function(){
        $("#myCarousel").carousel(2);
    });
    $(".item3").click(function(){
        $("#myCarousel").carousel(3);
    });

    $(".item4").click(function(){
        $("#myCarousel").carousel(3);
    });

});

</script>
    <section class="full-row make-it-possible">
<div class="container">
<div class="row">
<div class="col-sm-12">
<div class="col-sm-3">
<script src="//www.toyoursuccess.com/reviews/js:6187:4"></script>
</div>
<div class="col-sm-9">
<h2>Why Wait? Get Total Comfort Today!</h2>
<p>Honest Estimates. Affordable Prices. Experienced Technicians.</p> <br />
<p style="width:100%"><a class="btn btn-warning" href="<?php echo $base_url ?>/contact-us.php">Contact Our experts</a></p>
</div>
</div>
</div>
</div>
</section>
<!-- <section class="slider">

        <img src="img/banner.jpg" class="img-responsive"/>
        <div class="content text-center full-row visible-lg visible-md">

            <h1 class="text-white">The Best Service, Installation

                and Maintenance</h1>
            <p class="text-white">Make sure you are taking advantage of the year's best

                pricing and financing offers.</p>

        </div>
    </section>  -->
 <!--   <section class="full-row services">

        <div class="container">

            <div class="col-sm-4 item text-center">

                <div class="icon">

                   <img src="img/fixess.png">
                </div>

                <h3>New System Installation</h3>
                <p>Meet our incredible comfort systems incredibly installed by expert craftsmen.</p>

            </div>

            <div class="col-sm-4 item text-center">

                <div class="icon">

                   <img src="img/servicess.png">
                </div>

                <h3>Repair & Maintenance</h3>
                <p>Call Performance Heating and Cooling. And they’ll be on the job faster than you can reach for a blanket or a fan.</p>

            </div>

            <div class="col-sm-4 item text-center">

                <div class="icon">

                   <img src="img/schedulee.png">
                </div>

                <h3>Schedule an Appointment</h3>
                <p>Our friendly customer service representatives are ready to work with you and your busy your schedule.</p>

            </div>

        </div>
    </section>
-->
    <section class="full-row solutions text-center text-white">

        <div class="container">

                <div id="owl-demo1" class="owl-carousel1">
                	<a href="request-service.php">

                <div class="col-md-3 col-sm-6 col-xs-12 owl-item fade">

                    <div class="col-sm-12 item text-center">

                        <div class="icon">

                  <img src="img/2.png">
                        </div>

                        <h3>SCHEDULE A SERVICE CALL</h3>
                        <p class="slider-text">We offer both Scheduled and Emergency Service</p>
                    </div>
                </div>
</a>

<a href="financing.php">

                <div class="col-md-3 col-sm-6 col-xs-12 owl-item fade">

                    <div class="col-sm-12 item text-center ">

                        <div class="icon">

                   <img src="img/3.png">
                        </div>

                        <h3>FINANCING YOUR HOME COMFORT SYSTEM</h3>

                        <p class="slider-text">Simple online application process makes financing your new home comfort system as easy as possible</p>

                    </div>
                </div></a>

<a href="installations.php">

                <div class="col-md-3 col-sm-6 col-xs-12 owl-item fade">

                    <div class="col-sm-12 item text-center ">

                        <div class="icon">

                  <img src="img/4.png">
                        </div>

                        <h3>HEATING AND COOLING SYSTEM INSTALLATIONS</h3>
                        <p class="slider-text">We customize heating and cooling options to our customers specific comfort levels and budget.</p>

                    </div>
                </div>
</a>

                <!-- Solar Power Installations -->

<a href="air-quality.php">

                <div class="col-md-3 col-sm-6 col-xs-12 owl-item fade">
                    <div class="col-sm-12 item text-center ">
                        <div class="icon">
                   <img src="img/5_home.png">
                        </div>
                        <h3>INDOOR AIR QUALITY </h3>
                        <p class="slider-text">We offer air purifying products to help keep your indoor air as clean and safe as it can possibly be.</p>
                    </div>
                </div>

</a>

                <!-- Solar Power Installations -->
                <!-- <div class="col-md-3 col-sm-6 col-xs-12 owl-item">

                    <div class="col-sm-12 item text-center">

                        <div class="icon">

                            <i class="fa fa-fire fa-4x"></i>
                        </div>

                        <h3>Heating &<br>

                            Air Conditioning</h3>
                        <p class="slider-text">We've come a long way from the coal furnaces and stokers we installed for your grandparents.

                            See

                            how

                            our 93-year relationship with Lennox and our Premier Dealer status puts us on the cutting

                            edge

                            of

                            today's HVAC technology.</p>

                    </div>
                </div> -->

                <!-- <div class="col-md-3 col-sm-6 col-xs-12 owl-item">

                    <div class="col-sm-12 item text-center ">

                        <div class="icon">

                            <i class="fa fa-life-ring fa-4x"></i>
                        </div>

                        <h3>Ductless Mini-Split<br>

                            Solutions</h3>
                        <p class="slider-text">Meet tomorrow's technology today. Learn how a Mitsubishi ductless mini-split system is the

                            perfect

                            cost-saving solution for your hard to heat and cool spaces and now even your whole home.</p>

                    </div>
                </div> -->

                <!-- <div class="col-md-3 col-sm-6 col-xs-12 owl-item">

                    <div class="col-sm-12 item text-center ">

                        <div class="icon">

                            <i class="fa fa-bolt fa-4x"></i>
                        </div>

                        <h3>Whole-Home Standby

                            Generators</h3>
                        <p class="slider-text">Picture the coldest, sub-zero, snowy day or the hottest, most miserable summer afternoon how

                            would

                            your home or business fare if it lost power for 12, 24, even 36 or more hours? See why a

                            whole-home.</p>

                    </div>
                </div> -->                <!-- Solar Power Installations -->
                <!-- <div class="col-md-3 col-sm-6 col-xs-12 owl-item">
                    <div class="col-sm-12 item text-center ">
                        <div class="icon">
                            <i class="fa fa-wrench fa-4x"></i>
                        </div>
                        <h3>Solar Power <br>Installations</h3>
                        <p class="slider-text">What if the heating and cooling system in your home or business actually generated MORE energy than it consumed?  What would that mean for your budget?  For the environment?  Learn how a Lennox SunSource solar energy system and an ongoing tax credit make it possible.
                        </p>
                    </div>
                </div> -->
                <!-- Solar Power Installations -->
            </div>

        </div>
    </section>

    <section class="full-row testmonial">

        <div class="container">

            <div class="col-sm-12 text-center">

                <h2>What our Customers

                    are saying</h2>

            </div>

            <div id="testmonial" class="owl-carousel">
                <!--slider list-->

                <div class="col-sm-12 item  owl-item">

                 <p class="light text-center "><p class="light text-center ">I have been using this company for my HVAC work for 1-2 years, have always been very responsive, excellent work, reasonable prices. Can’t put a price on trust in knowing it will be done right.</p>

                <h3 class="text-center">J. C Heath </h3>

                </div>

                <!--slider list-->
                <!--slider list-->

                <div class="col-sm-12 item  owl-item">

                  <p class="light text-center "><p class="light text-center ">Great experience! We had both our furnace and A/C replaced. Proposal included options, and suggestions were given as to what would work best for us. The installation only took one day.</p>

                <h3 class="text-center">J. L Millersport</h3>

                </div>

                <!--slider list-->
                <!--slider list-->

        <div class="col-sm-12 item  owl-item">

                  <p class="light text-center "><p class="light text-center ">Love our new furnace and AC!! The service we received before during and after has been fantastic!! The staff are so professional.</p>

                <h3 class="text-center">D.B Reynoldsburg</h3>

                </div>

          <!--slider list-->
                <!--slider list-->

        <div class="col-sm-12 item  owl-item">

                  <p class="light text-center "><p class="light text-center ">Performance responded quickly to our issues with both the heating and air conditioning issues. The staff is very polite and helpful. Will be using them again.</p>

                <h3 class="text-center">P.G Gahanna</h3>

                </div>

            </div>

            <div class="col-sm-12 text-center">

                <a href="testimonials.php" class="btn btn-default">Read More</a>

            </div>
        </div>
    </section>

 <!--    <section class="full-row countries text-center text-white">

        <div class="container">

            <h2>We proudly service communities in the following Indiana and Illinois counties -</h2>
            <h3>(Indiana) Vigo, Clay, Fountain, Greene, Montgomery, Owen, Parke, Putnam, Sullivan, and Vermillion *

                (Illinois) Clark, Crawford, and Edgar</h3>

        </div>
    </section>

    <section class="full-row call text-center text-white">

        <div class="container">

            <h2>Call (812) 232-2347 <span>to make an appointment or book online</span></h2>

        </div>
    </section> -->
</main>

<?php include('footer.php'); ?>
